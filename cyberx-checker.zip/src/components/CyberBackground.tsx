import { useEffect, useRef } from "react";

export function CyberBackground() {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cols: { x: number; y: number; speed: number; chars: string[] }[] = [];
    const charset = "01░▒▓█ABCDEF0123456789✕✕✕";

    function resize() {
      w = canvas!.clientWidth; h = canvas!.clientHeight;
      canvas!.width = w * dpr; canvas!.height = h * dpr;
      ctx!.scale(dpr, dpr);
      cols.length = 0;
      const colW = 18;
      const n = Math.ceil(w / colW);
      for (let i = 0; i < n; i++) {
        cols.push({
          x: i * colW + 4,
          y: Math.random() * h,
          speed: 0.4 + Math.random() * 1.2,
          chars: Array.from({ length: 18 }, () => charset[(Math.random() * charset.length) | 0]),
        });
      }
    }

    function draw() {
      ctx!.fillStyle = "rgba(8, 12, 22, 0.18)";
      ctx!.fillRect(0, 0, w, h);
      ctx!.font = "13px JetBrains Mono, monospace";
      for (const c of cols) {
        for (let i = 0; i < c.chars.length; i++) {
          const yy = c.y - i * 16;
          if (yy < -16 || yy > h + 16) continue;
          const alpha = i === 0 ? 1 : Math.max(0, 0.55 - i * 0.035);
          ctx!.fillStyle = i === 0
            ? `rgba(180, 255, 245, ${alpha})`
            : `rgba(80, 220, 220, ${alpha})`;
          ctx!.fillText(c.chars[i], c.x, yy);
        }
        c.y += c.speed * 8;
        if (c.y - c.chars.length * 16 > h) {
          c.y = -Math.random() * 80;
          c.chars = c.chars.map(() => charset[(Math.random() * charset.length) | 0]);
        }
      }
      raf = requestAnimationFrame(draw);
    }

    resize();
    draw();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-60" />
      <canvas ref={ref} className="absolute inset-0 h-full w-full opacity-[0.18]" />
      <div
        className="absolute -top-32 left-1/2 h-[40rem] w-[40rem] -translate-x-1/2 rounded-full blur-3xl float-slow"
        style={{ background: "radial-gradient(circle, oklch(0.7 0.25 200 / 0.35), transparent 60%)" }}
      />
      <div
        className="absolute bottom-0 right-0 h-[30rem] w-[30rem] rounded-full blur-3xl float-slow"
        style={{ background: "radial-gradient(circle, oklch(0.6 0.28 320 / 0.22), transparent 60%)" }}
      />
    </div>
  );
}
