import { Link } from "@tanstack/react-router";
import { Shield, Newspaper, Activity } from "lucide-react";

export function Nav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/40 backdrop-blur-xl bg-background/60">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="group flex items-center gap-3">
          <div className="relative grid h-9 w-9 place-items-center rounded-lg neon-border bg-card">
            <Shield className="h-5 w-5 text-primary" />
            <div className="absolute inset-0 rounded-lg pulse-ring" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-display text-lg font-bold tracking-widest gradient-text">
              CYBERX
            </span>
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              Checker
            </span>
          </div>
        </Link>

        <nav className="flex items-center gap-1">
          <Link
            to="/"
            className="flex items-center gap-2 rounded-md px-4 py-2 font-mono text-sm text-muted-foreground transition hover:text-foreground"
            activeProps={{ className: "flex items-center gap-2 rounded-md px-4 py-2 font-mono text-sm text-primary bg-primary/10" }}
          >
            <Activity className="h-4 w-4" /> Scanner
          </Link>
          <Link
            to="/news"
            className="flex items-center gap-2 rounded-md px-4 py-2 font-mono text-sm text-muted-foreground transition hover:text-foreground"
            activeProps={{ className: "flex items-center gap-2 rounded-md px-4 py-2 font-mono text-sm text-primary bg-primary/10" }}
          >
            <Newspaper className="h-4 w-4" /> Cyber News
          </Link>
        </nav>
      </div>
    </header>
  );
}
