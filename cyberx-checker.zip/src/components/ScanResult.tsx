import { motion } from "motion/react";
import { Download, ExternalLink, FileText, ShieldAlert, ShieldCheck, ShieldQuestion, Globe, Hash, Network } from "lucide-react";
import type { ScanResult as TScanResult } from "@/lib/virustotal.functions";
import { downloadJsonReport, downloadPdfReport } from "@/lib/download-report";

const KIND_ICON = {
  url: Globe,
  domain: Globe,
  ip: Network,
  hash: Hash,
};

function VerdictBadge({ stats }: { stats: TScanResult["stats"] }) {
  const malicious = stats.malicious + stats.suspicious;
  if (malicious >= 5) return { label: "MALICIOUS", color: "text-destructive", bg: "bg-destructive/15", border: "border-destructive/40", Icon: ShieldAlert };
  if (malicious >= 1) return { label: "SUSPICIOUS", color: "text-warning", bg: "bg-warning/15", border: "border-warning/40", Icon: ShieldAlert };
  if (stats.harmless + stats.undetected > 0) return { label: "CLEAN", color: "text-success", bg: "bg-success/15", border: "border-success/40", Icon: ShieldCheck };
  return { label: "UNKNOWN", color: "text-muted-foreground", bg: "bg-muted/40", border: "border-border", Icon: ShieldQuestion };
}

export function ScanResult({ result }: { result: TScanResult }) {
  const verdict = VerdictBadge({ stats: result.stats });
  const KindIcon = KIND_ICON[result.kind];
  const total = result.totalEngines || 1;
  const detectionPct = ((result.stats.malicious + result.stats.suspicious) / total) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="relative mx-auto mt-10 w-full max-w-5xl overflow-hidden rounded-2xl glass scanline"
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />

      <div className="grid gap-6 p-6 md:grid-cols-[auto_1fr_auto] md:items-center md:p-8">
        <div className="flex items-center gap-4">
          <div className={`grid h-16 w-16 place-items-center rounded-2xl border ${verdict.border} ${verdict.bg}`}>
            <verdict.Icon className={`h-8 w-8 ${verdict.color}`} />
          </div>
          <div>
            <div className={`font-display text-2xl font-bold tracking-wider ${verdict.color}`}>
              {verdict.label}
            </div>
            <div className="mt-0.5 flex items-center gap-2 font-mono text-xs text-muted-foreground">
              <KindIcon className="h-3.5 w-3.5" />
              <span className="uppercase">{result.kind}</span>
              <span>·</span>
              <span>{total} engines</span>
            </div>
          </div>
        </div>

        <div className="min-w-0">
          <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Target</div>
          <div className="mt-1 truncate font-mono text-sm text-foreground" title={result.target}>
            {result.target}
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${detectionPct}%` }}
              transition={{ duration: 1.1, ease: "easeOut" }}
              className="h-full"
              style={{
                background: detectionPct > 0
                  ? "linear-gradient(90deg, oklch(0.7 0.2 50), oklch(0.65 0.25 25))"
                  : "linear-gradient(90deg, oklch(0.78 0.2 150), oklch(0.82 0.18 195))",
              }}
            />
          </div>
          <div className="mt-1 font-mono text-[11px] text-muted-foreground">
            {result.stats.malicious + result.stats.suspicious} / {total} engines flagged · {detectionPct.toFixed(1)}%
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => downloadPdfReport(result)}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 font-mono text-xs font-medium text-primary-foreground transition hover:opacity-90"
          >
            <FileText className="h-4 w-4" /> PDF Report
          </button>
          <button
            onClick={() => downloadJsonReport(result)}
            className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2 font-mono text-xs text-foreground transition hover:bg-muted"
          >
            <Download className="h-4 w-4" /> JSON
          </button>
          <a
            href={result.permalink}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2 font-mono text-xs text-foreground transition hover:bg-muted"
          >
            <ExternalLink className="h-4 w-4" /> VT
          </a>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-px border-t border-border/50 bg-border/40 sm:grid-cols-5">
        <Stat label="Malicious" value={result.stats.malicious} accent="text-destructive" />
        <Stat label="Suspicious" value={result.stats.suspicious} accent="text-warning" />
        <Stat label="Harmless" value={result.stats.harmless} accent="text-success" />
        <Stat label="Undetected" value={result.stats.undetected} accent="text-muted-foreground" />
        <Stat label="Timeout" value={result.stats.timeout} accent="text-muted-foreground" />
      </div>

      {Object.values(result.meta).some(Boolean) && (
        <div className="grid grid-cols-1 gap-4 border-t border-border/50 p-6 sm:grid-cols-2 md:grid-cols-3">
          {result.meta.title ? <Meta k="Title" v={String(result.meta.title)} /> : null}
          {result.meta.final_url ? <Meta k="Final URL" v={String(result.meta.final_url)} /> : null}
          {result.meta.country ? <Meta k="Country" v={String(result.meta.country)} /> : null}
          {result.meta.as_owner ? <Meta k="AS Owner" v={String(result.meta.as_owner)} /> : null}
          {result.meta.asn ? <Meta k="ASN" v={String(result.meta.asn)} /> : null}
          {result.meta.registrar ? <Meta k="Registrar" v={String(result.meta.registrar)} /> : null}
          {result.meta.type_description ? <Meta k="Type" v={String(result.meta.type_description)} /> : null}
          {result.meta.size ? <Meta k="Size" v={`${result.meta.size} bytes`} /> : null}
          {result.meta.md5 ? <Meta k="MD5" v={String(result.meta.md5)} mono /> : null}
          {result.meta.sha1 ? <Meta k="SHA1" v={String(result.meta.sha1)} mono /> : null}
          {result.meta.sha256 ? <Meta k="SHA256" v={String(result.meta.sha256)} mono /> : null}
          {result.lastAnalysisDate ? <Meta k="Last Analysis" v={new Date(result.lastAnalysisDate * 1000).toLocaleString()} /> : null}
        </div>
      )}

      <div className="border-t border-border/50 p-6">
        <h3 className="mb-4 font-display text-sm uppercase tracking-widest text-muted-foreground">
          Engine Detections ({result.engines.length})
        </h3>
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
          {result.engines.map((e, i) => (
            <motion.div
              key={e.engine}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: Math.min(i * 0.012, 0.6) }}
              className="flex items-center justify-between gap-2 rounded-md border border-border/40 bg-card/40 px-3 py-2 font-mono text-xs"
            >
              <span className="truncate text-foreground">{e.engine}</span>
              <span
                className={
                  e.category === "malicious" ? "text-destructive"
                  : e.category === "suspicious" ? "text-warning"
                  : e.category === "harmless" ? "text-success"
                  : "text-muted-foreground"
                }
              >
                {e.result || e.category}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function Stat({ label, value, accent }: { label: string; value: number; accent: string }) {
  return (
    <div className="bg-card/60 px-4 py-5 text-center">
      <div className={`font-display text-3xl font-bold ${accent}`}>{value}</div>
      <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
    </div>
  );
}

function Meta({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{k}</div>
      <div className={`mt-1 truncate text-sm text-foreground ${mono ? "font-mono text-xs" : ""}`} title={v}>{v}</div>
    </div>
  );
}
