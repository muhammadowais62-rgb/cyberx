import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { motion, AnimatePresence } from "motion/react";
import { Search, Loader2, AlertCircle } from "lucide-react";
import { scanTarget, type ScanResult as TScanResult } from "@/lib/virustotal.functions";
import { ScanResult } from "@/components/ScanResult";

const EXAMPLES = ["https://google.com", "8.8.8.8", "github.com", "44d88612fea8a8f36de82e1278abb02f"];

export function Scanner() {
  const scan = useServerFn(scanTarget);
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [result, setResult] = useState<TScanResult | null>(null);

  async function submit(v?: string) {
    const target = (v ?? value).trim();
    if (!target) return;
    setErr(null); setLoading(true); setResult(null);
    try {
      const r = (await scan({ data: { value: target } })) as TScanResult;
      setResult(r);
    } catch (e: any) {
      setErr(e?.message || "Scan failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="relative w-full">
      <form
        onSubmit={(e) => { e.preventDefault(); submit(); }}
        className="mx-auto w-full max-w-3xl"
      >
        <div className={`group relative overflow-hidden rounded-2xl glass transition ${loading ? "neon-glow" : ""}`}>
          {loading && <div className="absolute inset-x-0 top-0 h-px shimmer" />}
          <div className="flex items-center gap-3 p-2 pl-5">
            <Search className="h-5 w-5 shrink-0 text-primary" />
            <input
              type="text"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="Paste URL, domain, IP, or file hash (MD5/SHA-1/SHA-256)"
              className="flex-1 bg-transparent py-4 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
              autoFocus
            />
            <button
              type="submit"
              disabled={loading || !value.trim()}
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-primary-foreground transition hover:opacity-90 disabled:opacity-40"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              {loading ? "Scanning" : "Scan"}
            </button>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Try:</span>
          {EXAMPLES.map((ex) => (
            <button
              key={ex}
              type="button"
              onClick={() => { setValue(ex); submit(ex); }}
              className="rounded-md border border-border/60 bg-card/40 px-2.5 py-1 font-mono text-xs text-muted-foreground transition hover:border-primary/40 hover:text-primary"
            >
              {ex}
            </button>
          ))}
        </div>
      </form>

      <AnimatePresence>
        {err && (
          <motion.div
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="mx-auto mt-6 flex max-w-3xl items-start gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-4 font-mono text-sm text-destructive"
          >
            <AlertCircle className="mt-0.5 h-4 w-4" /> {err}
          </motion.div>
        )}
        {loading && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="mx-auto mt-10 max-w-3xl text-center"
          >
            <div className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">
              Querying 70+ engines via VirusTotal
            </div>
            <div className="mx-auto mt-4 grid h-1 w-64 overflow-hidden rounded-full bg-muted">
              <div className="h-full w-1/3 shimmer" />
            </div>
          </motion.div>
        )}
        {result && <ScanResult key={result.target} result={result} />}
      </AnimatePresence>
    </section>
  );
}
