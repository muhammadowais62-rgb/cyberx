import jsPDF from "jspdf";
import type { ScanResult } from "@/lib/virustotal.functions";

function safeName(s: string): string {
  return s.replace(/[^a-z0-9._-]+/gi, "_").slice(0, 80);
}

export function downloadJsonReport(r: ScanResult) {
  const blob = new Blob([JSON.stringify(r, null, 2)], { type: "application/json" });
  triggerDownload(blob, `cyberx-${r.kind}-${safeName(r.target)}.json`);
}

export function downloadPdfReport(r: ScanResult) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  let y = 50;

  // Header band
  doc.setFillColor(13, 18, 33);
  doc.rect(0, 0, pageW, 80, "F");
  doc.setTextColor(120, 240, 230);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text("CYBERX CHECKER", 40, 40);
  doc.setTextColor(180, 180, 200);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text("Threat Intelligence Report", 40, 58);
  doc.text(new Date().toLocaleString(), pageW - 40, 58, { align: "right" });

  y = 110;

  const malicious = r.stats.malicious + r.stats.suspicious;
  const verdict = malicious >= 5 ? "MALICIOUS" : malicious >= 1 ? "SUSPICIOUS" : "CLEAN";
  const verdictColor: [number, number, number] =
    verdict === "MALICIOUS" ? [220, 60, 60] : verdict === "SUSPICIOUS" ? [230, 170, 50] : [80, 200, 140];

  doc.setFontSize(28);
  doc.setTextColor(...verdictColor);
  doc.setFont("helvetica", "bold");
  doc.text(verdict, 40, y);

  y += 30;
  doc.setTextColor(40, 40, 50);
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.text(`Type: ${r.kind.toUpperCase()}`, 40, y);
  y += 18;

  doc.setFont("helvetica", "bold");
  doc.text("Target:", 40, y);
  doc.setFont("helvetica", "normal");
  const targetLines = doc.splitTextToSize(r.target, pageW - 130);
  doc.text(targetLines, 100, y);
  y += 16 * targetLines.length + 8;

  // Stats box
  doc.setDrawColor(220, 220, 230);
  doc.setFillColor(245, 247, 252);
  doc.roundedRect(40, y, pageW - 80, 70, 6, 6, "FD");
  const stats = [
    ["Malicious", r.stats.malicious, [220, 60, 60]],
    ["Suspicious", r.stats.suspicious, [230, 170, 50]],
    ["Harmless", r.stats.harmless, [80, 200, 140]],
    ["Undetected", r.stats.undetected, [120, 120, 130]],
    ["Timeout", r.stats.timeout, [120, 120, 130]],
  ] as const;
  const colW = (pageW - 80) / stats.length;
  stats.forEach(([label, val, color], i) => {
    const cx = 40 + colW * i + colW / 2;
    doc.setFontSize(20);
    doc.setTextColor(color[0], color[1], color[2]);
    doc.setFont("helvetica", "bold");
    doc.text(String(val), cx, y + 32, { align: "center" });
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 110);
    doc.setFont("helvetica", "normal");
    doc.text(String(label).toUpperCase(), cx, y + 52, { align: "center" });
  });
  y += 90;

  // Meta
  doc.setFontSize(12);
  doc.setTextColor(20, 20, 30);
  doc.setFont("helvetica", "bold");
  doc.text("Metadata", 40, y);
  y += 16;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  const metaPairs: Array<[string, string]> = [];
  if (r.lastAnalysisDate) metaPairs.push(["Last Analysis", new Date(r.lastAnalysisDate * 1000).toLocaleString()]);
  if (r.meta.country) metaPairs.push(["Country", String(r.meta.country)]);
  if (r.meta.as_owner) metaPairs.push(["AS Owner", String(r.meta.as_owner)]);
  if (r.meta.asn) metaPairs.push(["ASN", String(r.meta.asn)]);
  if (r.meta.registrar) metaPairs.push(["Registrar", String(r.meta.registrar)]);
  if (r.meta.type_description) metaPairs.push(["Type", String(r.meta.type_description)]);
  if (r.meta.size) metaPairs.push(["Size", `${r.meta.size} bytes`]);
  if (r.meta.md5) metaPairs.push(["MD5", String(r.meta.md5)]);
  if (r.meta.sha1) metaPairs.push(["SHA1", String(r.meta.sha1)]);
  if (r.meta.sha256) metaPairs.push(["SHA256", String(r.meta.sha256)]);
  for (const [k, v] of metaPairs) {
    if (y > pageH - 60) { doc.addPage(); y = 50; }
    doc.setTextColor(110, 110, 120);
    doc.text(`${k}:`, 40, y);
    doc.setTextColor(30, 30, 40);
    const lines = doc.splitTextToSize(v, pageW - 180);
    doc.text(lines, 140, y);
    y += 14 * lines.length;
  }

  y += 10;
  if (y > pageH - 80) { doc.addPage(); y = 50; }
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(20, 20, 30);
  doc.text(`Engine Detections (${r.engines.length})`, 40, y);
  y += 14;

  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  for (const e of r.engines) {
    if (y > pageH - 40) { doc.addPage(); y = 50; }
    const color: [number, number, number] =
      e.category === "malicious" ? [220, 60, 60]
      : e.category === "suspicious" ? [230, 170, 50]
      : e.category === "harmless" ? [80, 200, 140]
      : [140, 140, 150];
    doc.setTextColor(40, 40, 50);
    doc.text(e.engine, 40, y);
    doc.setTextColor(...color);
    const r2 = (e.result || e.category).toString().slice(0, 60);
    doc.text(r2, pageW - 40, y, { align: "right" });
    y += 13;
  }

  // Footer
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 150);
    doc.text(`CyberX Checker · Powered by VirusTotal · Page ${i}/${pages}`, pageW / 2, pageH - 20, { align: "center" });
  }

  doc.save(`cyberx-${r.kind}-${safeName(r.target)}.pdf`);
}

function triggerDownload(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
