import { createServerFn } from "@tanstack/react-start";
import { XMLParser } from "fast-xml-parser";

export type NewsItem = {
  title: string;
  link: string;
  description: string;
  pubDate: string;
  source: string;
  image?: string;
  category?: string;
};

const FEEDS: { name: string; url: string }[] = [
  { name: "The Hacker News", url: "https://feeds.feedburner.com/TheHackersNews" },
  { name: "BleepingComputer", url: "https://www.bleepingcomputer.com/feed/" },
  { name: "Krebs on Security", url: "https://krebsonsecurity.com/feed/" },
  { name: "Dark Reading", url: "https://www.darkreading.com/rss.xml" },
  { name: "Threatpost", url: "https://threatpost.com/feed/" },
];

function stripHtml(s: string): string {
  return (s || "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function findImage(item: any, html: string): string | undefined {
  const m1 = item?.["media:content"]?.["@_url"] || item?.["media:thumbnail"]?.["@_url"];
  if (m1) return m1;
  const enc = item?.enclosure?.["@_url"];
  if (enc) return enc;
  const m = /<img[^>]+src=["']([^"']+)["']/i.exec(html || "");
  return m?.[1];
}

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  trimValues: true,
});

async function fetchFeed(name: string, url: string): Promise<NewsItem[]> {
  try {
    const r = await fetch(url, {
      headers: { "user-agent": "CyberX-Checker/1.0", accept: "application/rss+xml, application/xml, text/xml" },
      signal: AbortSignal.timeout(12000),
    });
    if (!r.ok) return [];
    const xml = await r.text();
    const j = parser.parse(xml);
    const channel = j?.rss?.channel || j?.feed;
    const items: any[] = channel?.item || channel?.entry || [];
    return items.slice(0, 10).map((it) => {
      const desc = it.description || it.summary?.["#text"] || it.summary || it["content:encoded"] || "";
      const html = typeof desc === "string" ? desc : desc?.["#text"] || "";
      const linkRaw = it.link?.["@_href"] || it.link || "";
      const link = typeof linkRaw === "string" ? linkRaw : Array.isArray(linkRaw) ? (linkRaw[0]?.["@_href"] || linkRaw[0]) : "";
      const cat = Array.isArray(it.category) ? it.category[0] : it.category;
      return {
        title: stripHtml(typeof it.title === "string" ? it.title : it.title?.["#text"] || ""),
        link: String(link || ""),
        description: stripHtml(html).slice(0, 320),
        pubDate: it.pubDate || it.published || it.updated || "",
        source: name,
        image: findImage(it, html),
        category: typeof cat === "string" ? cat : cat?.["#text"],
      };
    }).filter((x) => x.title && x.link);
  } catch {
    return [];
  }
}

export const getCyberNews = createServerFn({ method: "GET" }).handler(async () => {
  const all = await Promise.all(FEEDS.map((f) => fetchFeed(f.name, f.url)));
  const flat = all.flat();
  flat.sort((a, b) => {
    const da = Date.parse(a.pubDate) || 0;
    const db = Date.parse(b.pubDate) || 0;
    return db - da;
  });
  return { items: flat.slice(0, 60), updatedAt: new Date().toISOString() };
});
