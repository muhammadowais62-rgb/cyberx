import { createServerFn } from "@tanstack/react-start";

const VT_API_KEY =
  process.env.VIRUSTOTAL_API_KEY ||
  "a6538b255fa2558cdc3d3e52dc5830da71980b20fab9195d0b5d26dbbf69d127";

const VT_BASE = "https://www.virustotal.com/api/v3";

type ScanInput = { value: string };

export type VTStats = {
  harmless: number;
  malicious: number;
  suspicious: number;
  undetected: number;
  timeout: number;
};

export type ScanResult = {
  kind: "url" | "domain" | "ip" | "hash";
  target: string;
  permalink: string;
  stats: VTStats;
  reputation?: number;
  categories?: Record<string, string>;
  lastAnalysisDate?: number;
  totalEngines: number;
  engines: Array<{
    engine: string;
    category: string;
    result: string | null;
    method?: string;
  }>;
  meta: {
    tags?: string[];
    title?: string;
    final_url?: string;
    type_description?: string;
    size?: number;
    md5?: string;
    sha1?: string;
    sha256?: string;
    first_submission?: number;
    times_submitted?: number;
    country?: string;
    asn?: number;
    as_owner?: string;
    whois_date?: number;
    registrar?: string;
    creation_date?: number;
  };
};

function detectKind(input: string): ScanResult["kind"] {
  const v = input.trim();
  if (/^[a-fA-F0-9]{32}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{64}$/.test(v)) return "hash";
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(v)) return "ip";
  if (/^https?:\/\//i.test(v)) return "url";
  if (/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(v)) return "domain";
  return "url";
}

async function vtFetch(path: string, init: RequestInit = {}): Promise<any> {
  const res = await fetch(`${VT_BASE}${path}`, {
    ...init,
    headers: {
      "x-apikey": VT_API_KEY,
      accept: "application/json",
      ...(init.headers || {}),
    },
  });
  const text = await res.text();
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* ignore */ }
  if (!res.ok) {
    const msg = json?.error?.message || text || `HTTP ${res.status}`;
    throw new Error(`VirusTotal: ${msg}`);
  }
  return json;
}

function urlIdFromUrl(u: string): string {
  // VT URL ID = base64url of the URL without padding
  // Use Node Buffer (server runtime)
  const b64 = Buffer.from(u, "utf-8").toString("base64");
  return b64.replace(/=+$/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function buildResult(kind: ScanResult["kind"], target: string, attrs: any): ScanResult {
  const stats: VTStats = {
    harmless: attrs.last_analysis_stats?.harmless ?? 0,
    malicious: attrs.last_analysis_stats?.malicious ?? 0,
    suspicious: attrs.last_analysis_stats?.suspicious ?? 0,
    undetected: attrs.last_analysis_stats?.undetected ?? 0,
    timeout: attrs.last_analysis_stats?.timeout ?? 0,
  };
  const total = Object.values(stats).reduce((a, b) => a + b, 0);
  const engines = Object.entries<any>(attrs.last_analysis_results || {}).map(
    ([engine, v]) => ({
      engine,
      category: v?.category ?? "unknown",
      result: v?.result ?? null,
      method: v?.method,
    }),
  );
  let permalink = "";
  if (kind === "url") permalink = `https://www.virustotal.com/gui/url/${urlIdFromUrl(target)}`;
  else if (kind === "domain") permalink = `https://www.virustotal.com/gui/domain/${target}`;
  else if (kind === "ip") permalink = `https://www.virustotal.com/gui/ip-address/${target}`;
  else permalink = `https://www.virustotal.com/gui/file/${target}`;

  return {
    kind,
    target,
    permalink,
    stats,
    reputation: attrs.reputation,
    categories: attrs.categories,
    lastAnalysisDate: attrs.last_analysis_date,
    totalEngines: total,
    engines: engines.sort((a, b) => {
      const order = { malicious: 0, suspicious: 1, harmless: 2, undetected: 3, timeout: 4 } as Record<string, number>;
      return (order[a.category] ?? 9) - (order[b.category] ?? 9);
    }),
    meta: {
      tags: attrs.tags,
      title: attrs.title,
      final_url: attrs.last_final_url,
      type_description: attrs.type_description,
      size: attrs.size,
      md5: attrs.md5,
      sha1: attrs.sha1,
      sha256: attrs.sha256,
      first_submission: attrs.first_submission_date,
      times_submitted: attrs.times_submitted,
      country: attrs.country,
      asn: attrs.asn,
      as_owner: attrs.as_owner,
      whois_date: attrs.whois_date,
      registrar: attrs.registrar,
      creation_date: attrs.creation_date,
    },
  };
}

async function pollAnalysis(analysisId: string): Promise<any> {
  for (let i = 0; i < 12; i++) {
    const a = await vtFetch(`/analyses/${analysisId}`);
    const status = a?.data?.attributes?.status;
    if (status === "completed") return a;
    await new Promise((r) => setTimeout(r, 2500));
  }
  return null;
}

export const scanTarget = createServerFn({ method: "POST" })
  .inputValidator((d: ScanInput) => {
    if (!d || typeof d.value !== "string" || d.value.trim().length === 0) {
      throw new Error("Provide a URL, domain, IP, or file hash.");
    }
    if (d.value.length > 2048) throw new Error("Input too long.");
    return { value: d.value.trim() };
  })
  .handler(async ({ data }): Promise<ScanResult> => {
    const kind = detectKind(data.value);

    if (kind === "hash") {
      const j = await vtFetch(`/files/${data.value}`);
      return buildResult("hash", data.value, j.data.attributes);
    }
    if (kind === "domain") {
      const j = await vtFetch(`/domains/${data.value}`);
      return buildResult("domain", data.value, j.data.attributes);
    }
    if (kind === "ip") {
      const j = await vtFetch(`/ip_addresses/${data.value}`);
      return buildResult("ip", data.value, j.data.attributes);
    }

    // URL: try existing report; if none/stale, submit new analysis
    const id = urlIdFromUrl(data.value);
    try {
      const j = await vtFetch(`/urls/${id}`);
      const attrs = j.data.attributes;
      const total = Object.values(attrs.last_analysis_stats || {}).reduce(
        (a: number, b: any) => a + (b as number), 0,
      );
      if (total > 0) return buildResult("url", data.value, attrs);
    } catch {
      // not yet analyzed
    }

    // submit
    const submit = await vtFetch(`/urls`, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: `url=${encodeURIComponent(data.value)}`,
    });
    const analysisId = submit?.data?.id;
    if (analysisId) await pollAnalysis(analysisId);
    const j2 = await vtFetch(`/urls/${id}`);
    return buildResult("url", data.value, j2.data.attributes);
  });
