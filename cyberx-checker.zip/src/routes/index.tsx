import { createFileRoute } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Scanner } from "@/components/Scanner";
import { ShieldCheck, Globe2, Hash, Network, Zap, Lock } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "CyberX Checker — VirusTotal-powered Threat Scanner" },
      { name: "description", content: "Scan URLs, domains, IPs, and file hashes against 70+ antivirus engines in seconds." },
    ],
  }),
});

const FEATURES = [
  { Icon: Globe2, title: "URLs & Domains", text: "Reputation across 70+ scanners" },
  { Icon: Network, title: "IP Addresses", text: "ASN, geolocation, malicious history" },
  { Icon: Hash, title: "File Hashes", text: "MD5, SHA-1, SHA-256 lookups" },
  { Icon: ShieldCheck, title: "Live Verdicts", text: "Malicious, suspicious, clean" },
  { Icon: Zap, title: "Real-time", text: "Powered by VirusTotal API v3" },
  { Icon: Lock, title: "Reports", text: "Download as PDF or JSON" },
];

function Index() {
  return (
    <main className="relative">
      <section className="relative px-6 pt-20 pb-10 md:pt-28">
        <div className="mx-auto max-w-5xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.3em] text-primary"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
            </span>
            Live · Powered by VirusTotal
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.05 }}
            className="mt-6 font-display text-5xl font-black leading-[1.05] tracking-tight md:text-7xl"
          >
            <span className="gradient-text">CyberX</span>
            <span className="text-foreground"> Checker</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.15 }}
            className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground md:text-lg"
          >
            Threat intelligence at the speed of light. Scan any URL, domain, IP, or file hash against
            70+ antivirus engines and download a forensic-grade report in seconds.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-12"
          >
            <Scanner />
          </motion.div>
        </div>
      </section>

      <section className="px-6 py-20">
        <div className="mx-auto max-w-6xl">
          <h2 className="font-display text-center text-xs uppercase tracking-[0.4em] text-muted-foreground">
            Capabilities
          </h2>
          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(({ Icon, title, text }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                className="group relative overflow-hidden rounded-xl border border-border/60 bg-card/40 p-6 transition hover:border-primary/40"
              >
                <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/10 blur-3xl transition group-hover:bg-primary/20" />
                <Icon className="h-7 w-7 text-primary" />
                <h3 className="mt-4 font-display text-lg font-bold text-foreground">{title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border/40 px-6 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 text-center md:flex-row md:text-left">
          <p className="font-mono text-xs text-muted-foreground">
            © {new Date().getFullYear()} CyberX Checker · Threat data via{" "}
            <a className="text-primary hover:underline" href="https://www.virustotal.com" target="_blank" rel="noreferrer">VirusTotal</a>
          </p>
          <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            Stay vigilant · Stay secure
          </p>
        </div>
      </footer>
    </main>
  );
}
