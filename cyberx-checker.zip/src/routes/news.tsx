import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { ExternalLink, Loader2, Newspaper, RefreshCw, AlertCircle } from "lucide-react";
import { getCyberNews, type NewsItem } from "@/lib/news.functions";
import { useState } from "react";

export const Route = createFileRoute("/news")({
  component: NewsPage,
  head: () => ({
    meta: [
      { title: "Cyber News — CyberX Checker" },
      { name: "description", content: "Latest cybersecurity news, breaches, and vulnerabilities aggregated from top sources." },
    ],
  }),
});

function NewsPage() {
  const fetchNews = useServerFn(getCyberNews);
  const q = useQuery({
    queryKey: ["cyber-news"],
    queryFn: () => fetchNews(),
    staleTime: 1000 * 60 * 5,
  });
  const [filter, setFilter] = useState<string>("All");

  const sources = ["All", ...Array.from(new Set((q.data?.items || []).map((i) => i.source)))];
  const items = (q.data?.items || []).filter((i) => filter === "All" || i.source === filter);

  return (
    <main className="px-6 py-12">
      <div className="mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between"
        >
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/5 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.3em] text-accent">
              <Newspaper className="h-3 w-3" /> Real-time
            </div>
            <h1 className="mt-3 font-display text-4xl font-black tracking-tight md:text-5xl">
              <span className="gradient-text">Cyber</span> Newsroom
            </h1>
            <p className="mt-2 text-muted-foreground">
              Latest breaches, vulnerabilities and threat intel from top security publications.
            </p>
          </div>
          <button
            onClick={() => q.refetch()}
            disabled={q.isFetching}
            className="inline-flex items-center gap-2 self-start rounded-md border border-border bg-card/50 px-4 py-2 font-mono text-xs transition hover:border-primary/40 hover:text-primary md:self-auto"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${q.isFetching ? "animate-spin" : ""}`} />
            Refresh
          </button>
        </motion.div>

        {q.data && (
          <div className="mt-8 flex flex-wrap gap-2">
            {sources.map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={`rounded-full border px-3 py-1 font-mono text-xs transition ${
                  filter === s
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border/60 text-muted-foreground hover:text-foreground"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        )}

        {q.isLoading && (
          <div className="mt-20 flex flex-col items-center gap-3 text-muted-foreground">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="font-mono text-sm">Aggregating threat intel feeds...</p>
          </div>
        )}

        {q.isError && (
          <div className="mt-10 flex items-center gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-destructive">
            <AlertCircle className="h-4 w-4" />
            <span className="font-mono text-sm">Failed to load news. Try refresh.</span>
          </div>
        )}

        {q.data && (
          <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {items.map((it, i) => (
              <NewsCard key={it.link + i} item={it} index={i} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

function NewsCard({ item, index }: { item: NewsItem; index: number }) {
  const date = item.pubDate ? new Date(item.pubDate) : null;
  return (
    <motion.a
      href={item.link}
      target="_blank"
      rel="noreferrer"
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.45, delay: Math.min(index * 0.03, 0.5) }}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border/60 bg-card/50 transition hover:-translate-y-0.5 hover:border-primary/50 hover:bg-card"
    >
      <div className="relative aspect-[16/9] overflow-hidden bg-muted">
        {item.image ? (
          <img
            src={item.image}
            alt=""
            loading="lazy"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
          />
        ) : (
          <div className="grid h-full w-full place-items-center">
            <Newspaper className="h-10 w-10 text-muted-foreground/40" />
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-card to-transparent" />
        <div className="absolute left-3 top-3 rounded-md bg-background/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-primary backdrop-blur">
          {item.source}
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-bold leading-snug text-foreground transition group-hover:text-primary">
          {item.title}
        </h3>
        <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{item.description}</p>
        <div className="mt-4 flex items-center justify-between border-t border-border/40 pt-3 font-mono text-[11px] text-muted-foreground">
          <span>{date ? date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : ""}</span>
          <span className="inline-flex items-center gap-1 text-primary opacity-0 transition group-hover:opacity-100">
            Read <ExternalLink className="h-3 w-3" />
          </span>
        </div>
      </div>
    </motion.a>
  );
}
